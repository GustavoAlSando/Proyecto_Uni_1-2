const listaPaises = document.getElementById("lista-paises");
const buscarPais = document.getElementById("buscar-pais");
let paises = JSON.parse(localStorage.getItem("paises")) || [];
    
function mostrarPaises(lista) {
    listaPaises.innerHTML = "";
    lista.forEach(pais => {
        const li = document.createElement("li");
        li.textContent = pais.name.common;
        li.addEventListener("click", () => mostrarDetallesPais(pais));
        listaPaises.appendChild(li);
    });
}
    
function mostrarDetallesPais(pais) {
    document.getElementById("modal-nombre").textContent = pais.name.common;
    document.getElementById("modal-capital").textContent = pais.capital ? pais.capital[0] : "N/A";
    document.getElementById("modal-poblacion").textContent = pais.population.toLocaleString();
    document.getElementById("modal-bandera").src = pais.flags.svg;
    document.getElementById("modal-bandera").alt = `Bandera de ${pais.name.common}`;

    let modal = new bootstrap.Modal(document.getElementById("paisModal"));
    modal.show();
}
    
buscarPais.addEventListener("input", () => {
    const filtro = buscarPais.value.toLowerCase();
    const paisesFiltrados = paises.filter(pais => 
        pais.name.common.toLowerCase().includes(filtro)
    );
    mostrarPaises(paisesFiltrados);
});

if (paises.length > 0) {
    mostrarPaises(paises);
}

document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.getElementById("menu-toggle");
    const navMenu = document.getElementById("nav-menu");

    //Me activa el menu hamburguesa
    menuToggle.addEventListener("click", function () {
        navMenu.classList.toggle("active");
    });
});