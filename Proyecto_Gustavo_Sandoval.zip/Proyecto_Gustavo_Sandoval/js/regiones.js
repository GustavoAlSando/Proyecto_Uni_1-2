document.addEventListener("DOMContentLoaded", function () {
    const apiURL = "https://restcountries.com/v3.1/region/";
    const seleccionarRegion = document.getElementById("seleccionar-region");
    const listaRegiones = document.getElementById("lista-regiones");

    seleccionarRegion.addEventListener("change", async () => {
        const region = seleccionarRegion.value;
        if (region) {
            try {
                const respuesta = await fetch(apiURL + region);
                const paises = await respuesta.json();
                mostrarPaisesPorRegion(paises);
            } catch (error) {
                console.error("Error al obtener países por región:", error);
            }
        }
    });

    function mostrarPaisesPorRegion(paises) {
        listaRegiones.innerHTML = "";
        paises.forEach(pais => {
            const li = document.createElement("li");
            li.textContent = pais.name.common;
            li.addEventListener("click", () => mostrarDetallesPais(pais));
            listaRegiones.appendChild(li);
        });
    }


    function mostrarDetallesPais(pais) {
        document.getElementById("modal-nombre").textContent = pais.name.common;
        document.getElementById("modal-capital").textContent = pais.capital ? pais.capital[0] : "N/A";
        document.getElementById("modal-poblacion").textContent = pais.population.toLocaleString();
        document.getElementById("modal-bandera").src = pais.flags.svg;
    
        let modal = new bootstrap.Modal(document.getElementById("paisModal"));
        modal.show();
    }

    const menuToggle = document.getElementById("menu-toggle");
    const navMenu = document.getElementById("nav-menu");
    menuToggle.addEventListener("click", function () {
        navMenu.classList.toggle("active");
    });
});