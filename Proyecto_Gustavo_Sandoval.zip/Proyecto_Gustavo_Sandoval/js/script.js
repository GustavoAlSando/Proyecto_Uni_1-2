async function cargarListaPaises() {
    let paises = JSON.parse(localStorage.getItem("paises"));
    if (!paises) {
        try {
            const respuesta = await fetch(apiURL);
            paises = await respuesta.json();
            localStorage.setItem("paises", JSON.stringify(paises));
        } catch (error) {
            console.error("Error al obtener los países:", error);
        }
    }
}
cargarListaPaises();

// Menú hamburguesa
const menuToggle = document.getElementById("menu-toggle");
const navMenu = document.getElementById("nav-menu");

menuToggle.addEventListener("click", function () {
    navMenu.classList.toggle("active");
});

document.addEventListener("DOMContentLoaded", function () {
    const apiURL = "https://restcountries.com/v3.1/all";
});

